# ------------------------------------------------------------
# Create table provisioner_log
# ------------------------------------------------------------

CREATE TABLE provisioner_log
(
	id         int NOT NULL IDENTITY (1, 1),
	dtime      datetime NULL,
    loglevel   varchar(8) NULL,
    classname  varchar(255) NULL,
    message    varchar(MAX) NULL,
	channelcode varchar(255) NULL
)  ON [PRIMARY]
GO
